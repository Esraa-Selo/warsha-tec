import{a$ as o,o as n,j as t,bo as e}from"./index.7e772701.js";const a={__name:"index copy",setup(c){return o(),(r,s)=>(n(),t("div",null,"worker"))}};typeof e=="function"&&e(a);export{a as default};
