import{c as e}from"./VAvatar.79550e70.js";const a=e("flex-grow-1","div","VSpacer");export{a as V};
