import{ba as i}from"./index.7e772701.js";const t=()=>i();export{t as u};
